This package is show you how to use bash command
================================================

PyPi: https://pypi.org/project/basicbashcmd

Installation
------------

Launch CMD / Terminal

.. code:: python

   pip install basicbashcmd

Usage
-----

-  Launch IDLE and type…

.. code:: python

   from basicbash import Bash
   b = Bash()
   b.list()
   b.desc('cd')
   b.cmd('cp')
